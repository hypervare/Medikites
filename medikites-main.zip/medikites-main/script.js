const swiper = new Swiper('.swiper', {
    // Optional parameters
    loop: true,
    autoplay:{
        delay:2000,
    }

  });